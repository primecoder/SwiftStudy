//
//  BottomHalfModalSheetApp.swift
//  BottomHalfModalSheet
//
//  Created by random on 8/4/21.
//

import SwiftUI

@main
struct BottomHalfModalSheetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
